var struct_m_d___u_i_switch___matrix_1_1ui_analog_keys__t =
[
    [ "adcThreshold", "struct_m_d___u_i_switch___matrix_1_1ui_analog_keys__t.html#aea4b183b81d441c423239faa632b1ec4", null ],
    [ "adcTolerance", "struct_m_d___u_i_switch___matrix_1_1ui_analog_keys__t.html#abb6c85f5bb926962631eb7b804d66f8c", null ],
    [ "value", "struct_m_d___u_i_switch___matrix_1_1ui_analog_keys__t.html#a38138276094cb20ba74ab3db1a9e7c2c", null ]
];