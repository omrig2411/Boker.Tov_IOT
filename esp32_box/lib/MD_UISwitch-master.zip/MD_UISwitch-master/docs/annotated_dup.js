var annotated_dup =
[
    [ "MD_UISwitch", "class_m_d___u_i_switch.html", "class_m_d___u_i_switch" ],
    [ "MD_UISwitch_4017KM", "class_m_d___u_i_switch__4017_k_m.html", "class_m_d___u_i_switch__4017_k_m" ],
    [ "MD_UISwitch_Analog", "class_m_d___u_i_switch___analog.html", "class_m_d___u_i_switch___analog" ],
    [ "MD_UISwitch_Digital", "class_m_d___u_i_switch___digital.html", "class_m_d___u_i_switch___digital" ],
    [ "MD_UISwitch_Matrix", "class_m_d___u_i_switch___matrix.html", "class_m_d___u_i_switch___matrix" ]
];