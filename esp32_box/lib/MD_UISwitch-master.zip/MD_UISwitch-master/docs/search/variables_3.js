var searchData=
[
  ['key_5factive_5fstate',['KEY_ACTIVE_STATE',['../_m_d___u_i_switch_8h.html#a31b7db8ca6c72f2c2d1f35676ed7bf1c',1,'MD_UISwitch.h']]],
  ['key_5fdpress_5ftime',['KEY_DPRESS_TIME',['../_m_d___u_i_switch_8h.html#aae76c0b46684910532977ccf29720536',1,'MD_UISwitch.h']]],
  ['key_5fidx_5fundef',['KEY_IDX_UNDEF',['../_m_d___u_i_switch_8cpp.html#a44a273b882219541d3c742a48ff1e482',1,'MD_UISwitch.cpp']]],
  ['key_5flongpress_5ftime',['KEY_LONGPRESS_TIME',['../_m_d___u_i_switch_8h.html#ad04c46920a8921db4b689830ae664082',1,'MD_UISwitch.h']]],
  ['key_5fpress_5ftime',['KEY_PRESS_TIME',['../_m_d___u_i_switch_8h.html#af1bab82a608f38b24dbc3191e693a852',1,'MD_UISwitch.h']]],
  ['key_5frepeat_5ftime',['KEY_REPEAT_TIME',['../_m_d___u_i_switch_8h.html#a27b2004a2239fff75146367890c36b6d',1,'MD_UISwitch.h']]]
];
