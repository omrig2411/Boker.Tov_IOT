var searchData=
[
  ['debounce',['debounce',['../class_m_d___u_i_switch.html#a5a3bd9ad717ae33f34e9fa2eefbd1a41',1,'MD_UISwitch']]],
  ['dpress_5fenable',['DPRESS_ENABLE',['../_m_d___u_i_switch_8h.html#a71075720e1391402294a8128b87c0299',1,'MD_UISwitch.h']]]
];
