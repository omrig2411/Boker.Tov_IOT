var _m_d___u_i_switch_8cpp =
[
    [ "UI_DEBUG", "_m_d___u_i_switch_8cpp.html#ae321adfa3e1108dbb5d7fb9ff12eb967", null ],
    [ "UI_PRINT", "_m_d___u_i_switch_8cpp.html#afb4ccf6c6cc3e80df0a568a51fbd9411", null ],
    [ "UI_PRINTS", "_m_d___u_i_switch_8cpp.html#aa4367a8155af432b0dc1e782b48674ed", null ],
    [ "KEY_IDX_UNDEF", "_m_d___u_i_switch_8cpp.html#a44a273b882219541d3c742a48ff1e482", null ]
];