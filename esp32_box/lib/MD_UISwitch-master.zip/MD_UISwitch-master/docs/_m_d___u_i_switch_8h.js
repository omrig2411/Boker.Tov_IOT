var _m_d___u_i_switch_8h =
[
    [ "MD_UISwitch", "class_m_d___u_i_switch.html", "class_m_d___u_i_switch" ],
    [ "MD_UISwitch_Digital", "class_m_d___u_i_switch___digital.html", "class_m_d___u_i_switch___digital" ],
    [ "MD_UISwitch_Analog", "class_m_d___u_i_switch___analog.html", "class_m_d___u_i_switch___analog" ],
    [ "uiAnalogKeys_t", "struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t.html", "struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t" ],
    [ "MD_UISwitch_Matrix", "class_m_d___u_i_switch___matrix.html", "class_m_d___u_i_switch___matrix" ],
    [ "MD_UISwitch_4017KM", "class_m_d___u_i_switch__4017_k_m.html", "class_m_d___u_i_switch__4017_k_m" ],
    [ "ARRAY_SIZE", "_m_d___u_i_switch_8h.html#a6242a25f9d996f0cc4f4cdb911218b75", null ],
    [ "DPRESS_ENABLE", "_m_d___u_i_switch_8h.html#a71075720e1391402294a8128b87c0299", null ],
    [ "KEY_ACTIVE_STATE", "_m_d___u_i_switch_8h.html#a31b7db8ca6c72f2c2d1f35676ed7bf1c", null ],
    [ "KEY_DPRESS_TIME", "_m_d___u_i_switch_8h.html#aae76c0b46684910532977ccf29720536", null ],
    [ "KEY_LONGPRESS_TIME", "_m_d___u_i_switch_8h.html#ad04c46920a8921db4b689830ae664082", null ],
    [ "KEY_PRESS_TIME", "_m_d___u_i_switch_8h.html#af1bab82a608f38b24dbc3191e693a852", null ],
    [ "KEY_REPEAT_TIME", "_m_d___u_i_switch_8h.html#a27b2004a2239fff75146367890c36b6d", null ],
    [ "LONGPRESS_ENABLE", "_m_d___u_i_switch_8h.html#ae624d1696ade653ff7302c5d6a8055e0", null ],
    [ "REPEAT_ENABLE", "_m_d___u_i_switch_8h.html#a30909fe7f296d7a592876e8f23673801", null ],
    [ "REPEAT_RESULT_ENABLE", "_m_d___u_i_switch_8h.html#ae64d8ab4bff3ff8fe3474b9e722c6543", null ]
];